package javabasicprgs;
import java.util.Scanner;

public class Ifcondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
		int s=sc.nextInt();
	
		if (s>0) {
			System.out.println("i value is Positive");
	
		}
	
	else 
	{
		System.out.println("i value is Negative ");
	}}}

