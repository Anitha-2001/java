package javabasicprgs;
//class1/ 
class Java1 {
	   public void displyainfo() {
		   System.out.println("Java is Easy Language");
		
	      
	   }
	   public void dis() {
		   System.out.println("Java is OOPS Language");
		
	      
	   }
	}
//class2/ 
	class Java2 extends Java1{
	//method name should be same   
		public void displyainfo() {
			System.out.println("Java is simple but still");
			super.displyainfo();
			super.dis();
			
		
	    
	   }
	}

	


public class MethodOverrideJava {

public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Java2 ja=new Java2();
		ja.displyainfo();
	}

}
