package javabasicprgs;
import java.util.Scanner;
public class Progfor5table {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int mul = scanner.nextInt();
        
        System.out.println("Multiplication table of " + mul + ":");
        for (int i = 1; i <= 20; i++) {
            System.out.println(mul + " x " + i + " = " + (mul * i));
        }
    }
}
