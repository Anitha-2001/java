package javabasicprgs;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int i = 0;
		do { 
	
	System.out.println("Output");
	i++;
      }while (i<3);
		
	}
	
	
	

}
