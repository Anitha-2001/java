package javabasicprgs;

public class Mainmethodexpl {
	
 public  static void main(String[] args) {
	
	        System.out.println("Main method with String[] args");
	    }

 public  static void main(String arg1) {
	        System.out.println("Main method with String arg1");
	    }

 public  static void main(String arg1, String arg2) {
	        System.out.println("Main method with String arg1 and String arg2");
	    }
	}
