package javabasicprgs;

import java.util.Scanner;

public class OddorEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//*Algorithm: 
		//1. Get the value from user
		//2. Given divide the number with 2
		//3. diveded  number is =0 then it is even
		//4. else odd 
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
		int s=sc.nextInt();
		if (s%2==0) {
			System.out.println("given No is even");
		}
		else 
		{
			System.out.println("Give no is odd");
		}
		
	

	}

}

