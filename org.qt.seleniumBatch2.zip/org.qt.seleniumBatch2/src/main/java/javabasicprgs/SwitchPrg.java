package javabasicprgs;

public class SwitchPrg {

	public static void main(String[] args) {
		// {
	    //TODO Auto-generated method stub
		//public static void main(String[] args)     int dayOfWeek = 3; // Assuming 1 represents Monday, 2 represents Tuesday, and so on.
        int Chrome, IE; 
	        switch (Chrome) {
	            case 1:
	                System.out.println("My browser is chrome.");
	                
	                break;
	            case 2: 
	            	System.out.println("Tuesday");
	            	{
	            		
	            	}

	            case 3: 
	            	System.out.println("Wednesday");

	}

}
