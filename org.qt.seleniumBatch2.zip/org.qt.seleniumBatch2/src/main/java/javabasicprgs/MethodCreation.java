package javabasicprgs;

public class ACB {
	
	
	
	public static void main(String[] args) {
		MethodCreation mc = new MethodCreation();
		mc.multi();
	}

}
