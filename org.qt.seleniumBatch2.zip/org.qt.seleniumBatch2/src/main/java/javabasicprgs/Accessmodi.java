package javabasicprgs;

 protected class Accessmodi {
	
	private void sub() {
		System.out.println("Hi!!");
	}
	
	 protected void add() {
		System.out.println("Hello!!");
	}
	

 void mul() {
		 System.out.println("Mult");
		 
	 }
	 
	  void div() {
		 System.out.println("Mult");
		 
	 }

	public  void main(String[] args) {
		
		 int i =10;
		Accessmodi ac= new Accessmodi();
	ac.add();
	ac.sub();
	ac.mul();
	ac.div();
		
		
		
		// TODO Auto-generated method stub

	}

}
