package javabasicprgs;

public  class StaticExample {
	 static int i=10;
	
	public static void add() {
		System.out.println("Hello");
	}

	public static int  mul() {
		int a =10;
		int b=20;
		int c =a*b;
		
		return c;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int j=15;//local variable
		System.out.println(j);
		System.out.println(i);
		int s=StaticExample.mul();
		

	}

}
