package javabasicprgs;

 
 class Methodadd {
	public int add(int a,int b)
	{
		int c=a+b;
         return c;
}
	
	public float add(float a ,float f,int e)
	{
		float d=a+f+e;
		return d; 

}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			
			Methodadd ads=new Methodadd();
			ads.add(12, 24);
			ads.add(12.0f, 24.0f, 31);
		}

	}


 
