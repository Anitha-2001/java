package javaclass;

public class MethodCreation {
	
	public void sum() {
		int a= 10;
		int b=20;
		int c =a+b;
		System.out.println(c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//MethodCreation mc = new MethodCreation();
		//mc.sum();
		int a =10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	}

}
