package selectclass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
//Import the Select class
import org.openqa.selenium.support.ui.Select;

public class selectprogexample {
	
public static void main(String[] args) {
	
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	options.merge(capabilities);
	ChromeDriver driver = new ChromeDriver(options);
	driver.get("https://demo.automationtesting.in/Register.html");
	

	// Locate the drop-down elements for day, month and year
	WebElement Skill = driver.findElement(By.id("Skills"));


	// Create Select instances for each drop-down element
	Select selectskills = new Select(Skill);
	

	// Select your birthday using different methods

	selectskills.selectByIndex(10); // Selects 15th day
	selectskills.selectByValue("C");



}
}