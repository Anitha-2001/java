package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FaceBook {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		 driver.get("https://www.facebook.com/");
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//div[@class='_6ltg']/a")).click();
		 Thread.sleep(4000);
       driver.findElement(By.name("firstname")).sendKeys("Kauslaya");
       Thread.sleep(4000);
				
				
				driver.findElement(By.name("lastname")).sendKeys("KR");
				Thread.sleep(4000);
				driver.findElement(By.name("lastname")).sendKeys("KR");
				Thread.sleep(3000);
				driver.findElement(By.name("reg_email__")).sendKeys("sgj@gmail.com");
				Thread.sleep(3000);
				WebElement signup= driver.findElement(By.className("websubmit"));
				signup.click();
				Thread.sleep(4000);
				driver.close();

	}

}
