package locators;



import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class LinkedIn {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://linkedin.com/?original_referer=");
		
		driver.findElement(By.xpath("//input[@id='session_key']")).sendKeys("kausalya24@gmail.com");
		
		driver.findElement(By.xpath("//input[@id='session_password']")).sendKeys("Sathya@2010");
		driver.findElement(By.xpath("//div[@class='login__form_action_container ']/button")).click();
		// TODO Auto-generated method stub

	}

}
