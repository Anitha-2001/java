package inheritanceexample;
//Parent class
class one {
 public void print_one()
 {
     System.out.println("Welcome to Java");
 }
}

class two extends one {
 public void print_two() 
 { System.out.println("Java is Easy"); }
}

class three extends one{
	public void print_thrid()
	{
		System.out.println("No worries we can learn java");
	}
	class four extends one{
		public void print_thrid()
		{
			System.out.println("No worries we can learn java");
		}
}
public class SingleInherit {

	public static void main(String[] args) {
		three g = new three();
	
		
		//show them if we create object for only 2nd class what will happen 
	}

	
}
