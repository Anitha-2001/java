package inheritanceexample;

import java.util.Arrays;

public class JavaStudents extends TestingStudents {
	public void StudentsDetails() {
		String[] studentName={"Raghavan","Sathya","Prabha","TK"};
		int[] studentid= {11,12,13,14};
		System.out.println(studentName);
		System.out.println(studentid);
		System.out.println(Arrays.asList(studentName));
		System.out.println(Arrays.toString(studentid));
		
		super.StudentDetials();
	
	}
	
	
	

}
