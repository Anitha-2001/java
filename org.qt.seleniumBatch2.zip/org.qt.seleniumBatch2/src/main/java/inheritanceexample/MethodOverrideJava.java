package inheritanceexample;

class Java1 {
	   public void displayInfo() {
		   
		   System.out.println("Java is easy language");
	      
	      
	   }
public void displayInfo1() {
		   
		   System.out.println("Java is easy language1");
	      
	      
	   }
public void displayInfo2() {
	   
	   System.out.println("Java is easy language2");
   
   
}
	}

	class Java2 extends Java1  {
	//method name should be same   
		public void displayInfo() {
			System.out.println("Java IS oops");
			super.displayInfo1();
	   
	   }
	}
	public class MethodOverrideJava {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Java2 jv = new Java2();
			jv.displayInfo();
			jv.displayInfo();
			jv.displayInfo2();
		
		}




}
