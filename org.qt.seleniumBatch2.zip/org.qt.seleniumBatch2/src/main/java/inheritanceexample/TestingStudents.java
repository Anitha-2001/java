package inheritanceexample;

public class TestingStudents {
	public void StudentDetials() {
		String studentName="Kausalya";
		String studentName1="Kavya";
		String studentName2="RK";
		int studentid=10;
		int studentid1=13;
		int studentid2=13;
		System.out.println(studentName+" "+studentid);
		System.out.println(studentName1+" "+studentid1);
	System.out.println(studentName+" "+studentid);
	System.out.println(studentName1+" "+studentid2);
}

}
