package inheritanceexample;

public class UpdateStudentDetial  {
	public void StudentsDetails() {
		String[] studentName={"Raghavan","Sathya","Prabha","TK"};
		int[] studentid= {11,12,13,14};
		System.out.println(studentName);
		System.out.println(studentid);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JavaStudents ts= new JavaStudents();
		ts.StudentsDetails();
		
		}

}
