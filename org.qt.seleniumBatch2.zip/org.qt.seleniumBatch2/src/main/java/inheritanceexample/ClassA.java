package inheritanceexample;

public class ClassA {
	public void add() {
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	}

}
