package inheritanceexample;

 

	 // TODO Auto-generated method stub
		class Account {
		    private String accountNumber;
		    private double balance;

		    public Account(String accountNumber, double balance) {
		        this.accountNumber = accountNumber;
		        this.balance = balance;
		    }

		    public void deposit(double amount) {
		        balance += amount;
		        System.out.println("Deposited: $" + amount);
		    }

		    public void withdraw(double amount) {
		        if (balance >= amount) {
		            balance -= amount;
		            System.out.println("Withdrawn: $" + amount);
		        } else {
		            System.out.println("Insufficient balance");
		        }
		    }

		    public double getBalance() {
		        return balance;
		    }

		    public void printStatement() {
		        System.out.println("Account Number: " + accountNumber);
		        System.out.println("Balance: $" + balance);
		    }
		}

		class SavingsAccount extends Account {
		    private double interestRate;

		    public SavingsAccount(String accountNumber, double balance, double interestRate) {
		        super(accountNumber, balance);
		        this.interestRate = interestRate;
		    }

		    // Method overriding: Custom implementation of the deposit method for SavingsAccount
		    @Override
		    public void deposit(double amount) {
		        super.deposit(amount); // Call the superclass implementation
		        applyInterest(); // Apply interest after every deposit
		    }

		    private void applyInterest() {
		        double interest = getBalance() * interestRate / 100;
		        super.deposit(interest);
		        System.out.println("Interest applied: $" + interest);
		    }
		}
 
		public class RealTimeExample {
		    
			public static void main(String[] args) {
		        Account account = new SavingsAccount("SA-1234", 1000.0, 5.0);

		        account.deposit(500.0);
		        account.printStatement();

		        account.withdraw(200.0);
		        account.printStatement();
		    }
		}


	
 

