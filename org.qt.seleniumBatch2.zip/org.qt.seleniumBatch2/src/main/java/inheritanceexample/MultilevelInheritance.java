package inheritanceexample;

class Javaprg{  
void language(){System.out.println("Easy...");}  
}  
class objects extends Javaprg{  
void create(){System.out.println("Create Object is very easy in java...");}  
}  
class inherit extends Javaprg{  
void oops(){System.out.println("Inheritance is concepts in OOPS...");}  
}  

public class MultilevelInheritance {

	public static void main(String[] args) {
		inherit i=new inherit();  
		i.language();
		i.oops();

	}

}
