package string;

public class StringObject {
	StringBuffer str1 = new StringBuffer("Kausaluya");
	System.out.println(str1.hashCode());
	StringBuffer str2 = new StringBuffer("Kausaluya");
	System.out.println(str2.hashCode());
	//StringBuilder 

}
