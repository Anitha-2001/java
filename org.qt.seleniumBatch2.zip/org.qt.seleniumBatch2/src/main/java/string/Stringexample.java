package string;

public class Stringexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="Raghavan";
		String s1 ="Raghavan";
		System.out.println(s.endsWith("n"));
		System.out.println(s.charAt(3));
     s.length();
     String s2= new String(s);
     StringBuffer s4= new StringBuffer("Kausalya");
     StringBuilder s5= new StringBuilder("Kausalya");
     System.out.println(s4.hashCode());
     System.out.println(s5.hashCode());
     System.out.println(s2.hashCode());
//immutable
    System.out.println(s2.hashCode());
     System.out.println(s1.hashCode());
     
	}

}
