package interfaceexample;

public class prog1 {

}
