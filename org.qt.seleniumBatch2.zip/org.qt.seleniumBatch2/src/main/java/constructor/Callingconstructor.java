package constructor;

public class Callingconstructor{

    public static void main(String[] args) {
    	Constructorinitialization c1 = new Constructorinitialization("BMW","2012",2000, "Automatic");
    	Constructorinitialization c2 = new Constructorinitialization("Aulto","2010",1000, "Manual");
        
    	c1.displayInfo();
    	c2.displayInfo();
	}
	
}

