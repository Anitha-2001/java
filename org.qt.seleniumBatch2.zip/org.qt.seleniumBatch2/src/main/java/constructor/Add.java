package constructor;

public class Add {
	
	int a=10;
	int b=20;
  int c =a+b;

	public  Add(int a, int b, int c ) {

		this.a=a;
		this.b=b;
		this.c=c;
		System.out.println(c);
				
	}
	
	
}
