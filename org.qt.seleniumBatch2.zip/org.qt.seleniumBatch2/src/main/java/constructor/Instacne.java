package constructor;

public class Instacne {
	int i =10;
	int j=20;
	
	
			

}
