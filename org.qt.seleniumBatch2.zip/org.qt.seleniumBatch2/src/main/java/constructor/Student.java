package constructor;

public class Student {
	
	    private int id;
	    private String name;

	    // Constructor
	    public Student(int id, String name) {
	        this.id = id;
	        this.name = name;
	    }

	    // Copy constructor
	    public Student(Student Student1) {
	        this.id = Student1.id;
	        this.name = Student1.name;
	    }

	    // Getter and Setter methods

	    public void displayInfo() {
	        System.out.println("ID: " + id);
	        System.out.println("Name: " + name);
	    }

	    public static void main(String[] args) {
	        Student student1 = new Student(101, "Kausalya Raghavan");
	        Student student2 = new Student(102, "Sathya Raghavan");

	        // Using the copy constructor to create a new Student object
	        Student student3 = new Student(student2);

	        // Displaying information of both students
	        System.out.println("Student 1:");
	        student1.displayInfo();

	        System.out.println("\nStudent 2 (Copy of Student 1):");
	        student2.displayInfo();
	    }
	}



