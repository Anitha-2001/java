package constructor;

public class callinginstance extends Instacne {


}
