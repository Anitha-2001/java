package constructor;

public class Employeedetials {
	    public int empId;
	    public String empName;
	    public double salary;
	    public String catagry;

	    // Constructor to initialize employee data
	    public Employeedetials(int empId, String empName, double salary, String department) {
	        this.empId = empId;
	        this.empName = empName;
	        this.salary = salary;
	        this.catagry = department;
	    }

	    // Method to display employee information
	    public void displayInfo() {
	    	
	        System.out.println("Employee ID: " + empId);
	        System.out.println("Name: " + empName);
	        System.out.println("Salary: $" + salary);
	        System.out.println("Department: " + catagry);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        // Creating Employee objects using the constructor
	    	Employeedetials emp1 = new Employeedetials(101, "John Smith", 45000.0, "IT");
	    	Employeedetials emp2 = new Employeedetials(102, "Jane Doe", 52000.0, "HR");
	    	Employeedetials emp3 = new Employeedetials(103, "Michael Johnson", 60000.0, "Finance");
	    	Employeedetials emp4 = new Employeedetials(103, "Michael Johnson", 50000.0, "Finance");
            // unable to set the values from previosue one. so We are going with Encapsulation//
	        // Displaying employee information
	        emp1.displayInfo();
	        emp2.displayInfo();
	        emp3.displayInfo();
	        emp4.displayInfo();
	    }
	}



