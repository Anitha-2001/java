package constructor;

import org.openqa.selenium.WebDriver;

public class Constructorinitialization {
	 // Fields (instance variables)
    String make;
    String model;
    int year;
    String type;
    
    WebDriver dirver;
    
    
  public  Constructorinitialization(String make,String model, int year,String type) {
    
	this.make=make;
    this.model=model;
    this.year=year;
    this.type="Automatic";
    WebDriver driver = null;
	this.dirver=driver;
}



public void displayInfo() {
    System.out.println("Make: " + make);
    System.out.println("Model: " + model);
    System.out.println("Year: " + year);
    System.out.println("Type: " + type);
    }
}