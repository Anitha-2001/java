package constructor;

public class Empdetail2  extends Empdetail{

	public Empdetail2(int empId, String empName, double salary, String department) {
		super(empId, empName, salary, department);
		// TODO Auto-generated constructor stub
		this.empId = empId;
        this.empName = empName;
        this.salary = salary;
        this.department = department;
	
	}

}
