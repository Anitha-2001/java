package constructor;

public class Empdetail extends Employeedetials {
	
	public Empdetail(int empId, String empName, double salary, String department) {
		super(empId, empName, salary, department);
		// TODO Auto-generated constructor stub\
		   this.empId = empId;
	        this.empName = empName;
	        this.salary = salary;
	        this.department = department;
		
	}

	public static void  main(String[] args) {
	        // Creating Employee objects using the constructor
	    	
		Empdetail ev = new Empdetail(0, null, 0, null);
		ev.empId=1001;
		ev.salary=12442.00;
		System.out.println(ev.empId);
		
		public  void (String[] args) {
}}
