package constructor;

public class InstanceVaribaleexample {
	int i =10;
	
	public void add() {
		
		int i =10;
		
		
	}
	
	

	
}
