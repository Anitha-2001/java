package seleniumcode;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ParallelExecution {
	
	    public static void main(String[] args) {
	        // Set the system property for the ChromeDriver executable
	    	String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			System.out.println(driverPath);
			// Launch the browser
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.merge(capabilities);
			//ChromeDriver chromeDriver = new ChromeDriver(options);
			DesiredCapabilities dc = new DesiredCapabilities();
			dc.setCapability("marionatte", false);
			FirefoxOptions opt = new FirefoxOptions();
			opt.merge(dc);

	        // Set the system property for the GeckoDriver (Firefox) executable
	        System.setProperty("webdriver.gecko.driver", "D:\\geckodriver.exe");

	        // Set the system property for the EdgeDriver executable
	       // System.setProperty("webdriver.edge.driver", "path/to/msedgedriver");

	        // Create instances of different WebDriver implementations
	        WebDriver chromeDriver = new ChromeDriver(options);
	        WebDriver firefoxDriver = new FirefoxDriver(opt);
	        //WebDriver edgeDriver = new EdgeDriver(opt);

	        // Run tests on different browsers
	        runTest(chromeDriver, "Chrome");
	        runTest(firefoxDriver, "Firefox");
	        //runTest(edgeDriver, "Edge");

	        // Quit the WebDriver instances
	        chromeDriver.quit();
	        firefoxDriver.quit();
	        //edgeDriver.quit();
	    }

	    public static void runTest(WebDriver driver, String browserName) {
	        // Navigate to a website
	        driver.get("https://www.example.com");

	        // Perform some actions on the website
	        // ...

	        // Print browser information
	        System.out.println("Test completed on " + browserName);

	        // Wait for a while to see the browser in action
	        try {
	            Thread.sleep(2000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}



