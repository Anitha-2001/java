package seleniumcode;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class PromptAlert {
	
	    public static void main(String[] args) throws InterruptedException {
	        // Set the path to the ChromeDriver executable
	    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.merge(capabilities);
			ChromeDriver driver = new ChromeDriver(options);

	        // Navigate to the webpage containing a prompt alert
	        driver.get("https://nxtgenaiacademy.com/alertandpopup/");

	        // Find the button that triggers the prompt alert and click it
	        driver.findElement(By.name("promptalertbox1234")).click();

	        // Switch to the alert
	        Alert promptAlert = driver.switchTo().alert();

	        // Get the text of the prompt alert and print it
	        String alertText = promptAlert.getText();
	        System.out.println("Prompt Alert Text: " + alertText);

	        // Enter text into the prompt alert and accept it
	        Thread.sleep(30000);
	        String inputText = "YES!";
	        promptAlert.sendKeys(inputText);
	        promptAlert.accept();
	       System.out.println("Prompt Alert accepted with input: " + inputText);

	        // Close the browser
	        driver.quit();
	    }
	}



