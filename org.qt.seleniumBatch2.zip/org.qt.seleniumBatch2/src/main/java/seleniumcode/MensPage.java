package seleniumcode;

public class MensPage extends BaseInheritance {
	b.driver=dri er

}
