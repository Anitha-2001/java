package seleniumcode;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DragexDrop {
	
   public static void main(String[] args) throws InterruptedException {
	// Set the path to the chromedriver executable
	   String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
	   System.out.println(driverPath);
	   // Launch the browser
	   ChromeOptions options = new ChromeOptions();
	   options.addArguments("--remote-allow-origins=*");
	   DesiredCapabilities capabilities = new DesiredCapabilities();
	   capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	   options.merge(capabilities);
	   ChromeDriver driver = new ChromeDriver(options);

	        // Create a new instance of the Chrome WebDriver	
	      
	        // Open the desired URL
	        try {
	        	String url = "https://artoftesting.com/samplesiteforselenium";
	        
	        driver.get(url);
	        WebElement sourceElement = driver.findElement(By.xpath("//*[@id=\"myImage\"]"));

            // Find the target element (the element to drop onto)
            WebElement targetElement = driver.findElement(By.xpath("//*[@id=\"targetDiv\"]"));
            Actions actions = new Actions(driver);
            Thread.sleep(4000);
            actions.clickAndHold(sourceElement)
                     
            	    .moveToElement (targetElement)
            	    .release (targetElement)
            	    .build ();
            	   actions.
                    perform();
	      }finally {
	    	  
	    	  System.out.println("Working fine");
	      }
            
            //actions.dragAndDrop(sourceElement, targetElement).build().perform();
	    	  
   }}
            
