package seleniumcode;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Womenspage extends BaseInheritance {
	
	
public static void main(String[] args, WebDriver driver,String s) {
	Womenspage wp = new Womenspage();
	BaseInheritance.driver=driver;
	 WebElement womenTab = driver.findElement(By.linkText("Women"));
	 Actions actions = new Actions(driver);
     actions.moveToElement(womenTab).perform();
}	
}
