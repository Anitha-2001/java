package seleniumcode;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;


public class DragandDrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		       // Set the path to the chromedriver executable
		String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		System.out.println(driverPath);
		// Launch the browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);

		        // Create a new instance of the Chrome WebDriver
		      
		        // Open the desired URL
		        String url = "https://jqueryui.com/droppable/";
		        driver.get(url);

		        try {
		            // Switch to the iframe containing the drag and drop elements
		            driver.switchTo().frame(driver.findElement(By.cssSelector("iframe.demo-frame")));

		            // Find the source element (the element to be dragged)
		            WebElement sourceElement = driver.findElement(By.id("draggable"));

		            // Find the target element (the element to drop onto)
		            WebElement targetElement = driver.findElement(By.id("droppable"));

		            // Create an Actions object to perform the drag and drop action
		            Actions actions = new Actions(driver);
		            actions.dragAndDrop(sourceElement, targetElement).perform();
		        } finally {
		            // Return to the default content
		            driver.switchTo().defaultContent();

		            // Close the browser window
		            driver.quit();
		        }
		    }
		

	}


