package seleniumcode;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SimpleAlert {
	public static void main(String[] args) {
	        // Set the path to the ChromeDriver executable
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);

	       // Navigate to the webpage containing a simple alert
	        driver.get("https://nxtgenaiacademy.com/alertandpopup/");

	        // Find the button that triggers the alert and click it
	        driver.findElement(By.name("alertbox")).click();

	        // Switch to the alert
	        Alert simpleAlert = driver.switchTo().alert();

	        // Get the text of the alert and print it
	        String alertText = simpleAlert.getText();
	        System.out.println("Simple Alert Text: " + alertText);

	        // Accept the alert (click OK button)
	        simpleAlert.accept();
	        System.out.println("Simple Alert accepted.");

	        // Close the browser
	        driver.quit();
	    }
	}



