package seleniumcode;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
public class ConfirmationAlert {
	   public static void main(String[] args) {
	        // Set the path to the ChromeDriver executable
		   System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.merge(capabilities);
			ChromeDriver driver = new ChromeDriver(options);
	        // Navigate to the webpage containing a confirmation alert
	        driver.get("https://nxtgenaiacademy.com/alertandpopup/");

	        // Find the button that triggers the confirmation alert and click it
	        driver.findElement(By.name("confirmalertbox")).click();

	        // Switch to the alert
	        Alert confirmationAlert = driver.switchTo().alert();

	        // Get the text of the confirmation alert and print it
	        String alertText = confirmationAlert.getText();
	        System.out.println("Confirmation Alert Text: " + alertText);

	        // Accept the confirmation alert (click OK button)
	        confirmationAlert.accept();
	        System.out.println("Confirmation Alert accepted.");

	        // Or, dismiss the confirmation alert (click Cancel button)
	         confirmationAlert.dismiss();
	        System.out.println("Confirmation Alert dismissed.");

	        // Close the browser
	        driver.quit();
	    }
	}


