package seleniumcode;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class AutoSuggestion {
public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	options.merge(capabilities);
	ChromeDriver driver = new ChromeDriver(options);
	//Load the url
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	driver.get("http://www.google.com/");
    driver.manage().window().maximize();
    try {
        // Find the search input element by its name attribute
        WebElement searchInput = driver.findElement(By.name("q"));

        // Type a search query into the input field
        searchInput.sendKeys("Selenium");
 Thread.sleep(5000);
        // Simulate pressing the DOWN arrow key to select the first auto-suggestion
        searchInput.sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(5000);
        // Simulate pressing the ENTER key to choose the selected suggestion
        searchInput.sendKeys(Keys.ENTER);
    } finally {
        // Close the browser window
        driver.quit();
    }
}
}


	
	        
	    
	



