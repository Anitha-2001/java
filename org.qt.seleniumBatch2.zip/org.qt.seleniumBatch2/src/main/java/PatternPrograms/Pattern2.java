package PatternPrograms;

public class Pattern2
{
public static void main(String[] args) {
		{ 
			for (int i=1; i<=3; i++) {
				for (int j=5; j<=3; j++) {
					System.out.print(j);
					}
				System.out.print(i);
			}
			
			
			System.out.println();
	}}

}