package PatternPrograms;

public class Pattern7 {
	public static void main(String[] args) {
			// TODO Auto-generated method stub
	                  int size = 5;
				    int num = 1;
				    // upside pyramid
				    for (int i = 1; i <= size; i++) {
				      // printing spaces
				      for (int j = size; j > i; j--) {
				        System.out.print(" ");
				      }
				      // printing numbers
				      for (int k = 0; k < i * 2 -1; k++) {
				        System.out.print(num++);
				      }
				      num = 1;
				      System.out.println();
				    }
				    // downside pyramid
				    for (int i = 1; i <= size - 1; i++) {
				      // printing spaces
				      for (int j = 0; j < i; j++) {
				        System.out.print(" ");
				      }
				      // printing numbers
				      for (int k = (size - i) * 2 - 1; k > 0; k--) {
				        System.out.print(num++);
				      }
				      num = 1;
				      System.out.println();
				    }
				  }
				}


